package pdp_lessons.module2.lesson7.task5;

public abstract class Player {

    String sport;
    String team;
    String position;
    String first;
    String last;

    public abstract String getSport();

    public abstract void setSport(String sport);

    public abstract String getTeam();

    public abstract void setTeam(String team);

    public abstract String getPosition();

    public abstract void setPosition(String position);

    public abstract String getFirst();

    public abstract void setFirst(String first);

    public abstract String getLast();

    public abstract void setLast(String last);
}
